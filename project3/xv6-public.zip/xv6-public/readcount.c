#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(void) {

printf(1, "Read kutsujen maara tahan asti on : %d\n", grc());
exit();

}
